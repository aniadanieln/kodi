# -*- coding: cp1254 -*-
# for more info please visit http://www.iptvxtra.net


import sys,xbmc,xbmcaddon

if 'extrafanart' in sys.argv[2]: sys.exit(0)

if 'runstream' in sys.argv[2]:
    url = sys.argv[2].replace('?runstream=','')
    px = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-polen/resources/lib/zapping.py")
    xbmc.executebuiltin('RunScript('+px+',url='+url+')')
    sys.exit(0)

import resources.lib.requests as requests
import re,os,xbmcplugin,xbmcgui

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
Addon = xbmcaddon.Addon('plugin.video.iptvxtra-polen')
home = Addon.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'resources/lib/icon.png' ) )
eskaicon = xbmc.translatePath( os.path.join( home, 'resources/lib/eska.png' ) )
eskaricon = xbmc.translatePath( os.path.join( home, 'resources/lib/eskar.png' ) )
tvpicon = xbmc.translatePath( os.path.join( home, 'resources/lib/tvp.png' ) )
net = xbmc.translatePath( os.path.join( home, 'resources/lib/net.png') )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
mode = sys.argv[2]
koniec = xbmc.translatePath( os.path.join( home, 'resources/lib/koniec.png' ) )

def main():

    if 'xcat1' in mode: polen3()
    elif 'xcat2' in mode: eska()
    elif 'xcat3' in mode: polen1()
    elif 'xcat4' in mode: polen2()
    else:
        addDir('PROJEKT ZAKO�CZONY', 'plugin://plugin.video.iptvxtra-polen/?xcat3x', koniec)
        addDir('WTYCZKA NIEWSPIERANA', 'plugin://plugin.video.iptvxtra-polen/?xcat1x', koniec)
        addDir('POBIERZ NOWSZY ZAMIENNIK', 'plugin://plugin.video.iptvxtra-polen/?xcat2x', koniec)
        addDir('[COLOR yellow]Telewizja Polska[/COLOR]', 'plugin://plugin.video.iptvxtra-polen/?xcat4x', koniec)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        sys.exit(0)
    
def addLink(name,url,iconimage):
        ok=True
        if 'looknij.tv' in url: url = 'plugin://plugin.video.iptvxtra-polen/?runstream=' + url + '***' + name + '***' + iconimage	
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", iconimage )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,iconimage):
    print iconimage
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty( "Fanart_Image", icon )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

def get_url():

    basicurl = 'http://tvpstream.tvp.pl/'
    plurl = requests.get(basicurl)
    pattern = '<div class="button.*?data-video_id="([^"]+)" title="([^"]+)">.*?<img src="([^"]+)".*?</div>'
    rResult = parse(plurl.text, pattern)
    return rResult[1]

def find_between(s,first,last):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def parse(sHtmlContent, sPattern, iMinFoundValue = 1, ignoreCase = False):
        if ignoreCase:
            aMatches = re.compile(sPattern, re.DOTALL|re.I).findall(sHtmlContent)
        else:
            aMatches = re.compile(sPattern, re.DOTALL).findall(sHtmlContent)
        if (len(aMatches) >= iMinFoundValue):                
            return True, aMatches
        return False, aMatches

def eska():
    addLink("Zainstaluj nowszy dodatek o nazwie [COLOR yellow]Telewizja Polska[/COLOR]",'none','none')
    addLink("Wtyczka [COLOR yellow]Telewizja Polska[/COLOR] dost�pna jest w Repozytorium",'none','none')
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    sys.exit(0)


def tvp():
    link = get_url()
    for i in link:
        url = 'plugin://plugin.video.iptvxtra-polen/?runstream=' + i[0] + '***' + i[1] + '***' + i[2]
        addLink(i[1],url,i[2])
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    sys.exit(0)

def polen1():
    addLink("Zainstaluj nowszy dodatek o nazwie [COLOR yellow]Telewizja Polska[/COLOR]",'none','none')
    addLink("Wtyczka [COLOR yellow]Telewizja Polska[/COLOR] dost�pna jest w Repozytorium",'none','none')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    sys.exit(0)

def polen2():
    addLink("Zainstaluj nowszy dodatek o nazwie [COLOR yellow]Telewizja Polska[/COLOR]",'none','none')
    addLink("Wtyczka [COLOR yellow]Telewizja Polska[/COLOR] dost�pna jest w Repozytorium",'none','none')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    sys.exit(0)

def polen3():
    addLink("Zainstaluj nowszy dodatek o nazwie [COLOR yellow]Telewizja Polska[/COLOR]",'none','none')
    addLink("Wtyczka [COLOR yellow]Telewizja Polska[/COLOR] dost�pna jest w Repozytorium",'none','none')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    sys.exit(0)

main()




